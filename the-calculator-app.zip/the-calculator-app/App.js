import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput} from 'react-native';

const Calculator = () => {
  const [expression, setExpression] = useState('');
  const [result, setResult] = useState('');

  const handleOperator = (operator) => {
    setExpression(expression + operator);
  };

  const handleEqual = () => {
    const calculation = eval(expression);
    setResult(calculation.toString());
  };

  const handleClear = () => {
    setExpression('');
    setResult('');
  };

  return (
    <View style={styles.container}>
    <Text style={styles.heading}>THE CALCULATOR APP</Text>
    <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          value={expression}
          onChangeText={(text) => setExpression(text)}
          keyboardType="decimal-pad"
        />
      </View>
    
      <Text style={styles.expression}>{expression}</Text>
      <Text style={styles.result}>{result}</Text>
      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.button} onPress={() => handleOperator('+')}>
          <Text style={styles.buttonText}>+</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => handleOperator('-')}>
          <Text style={styles.buttonText}>-</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => handleOperator('*')}>
          <Text style={styles.buttonText}>*</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => handleOperator('/')}>
          <Text style={styles.buttonText}>/</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.button} onPress={handleEqual}>
          <Text style={styles.buttonText}>=</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={handleClear}>
          <Text style={styles.buttonText}>C</Text>
        </TouchableOpacity>
      </View>
    
     
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  expression: {
    fontSize: 24,
    marginBottom: 10,
  },
  result: {
    fontSize: 36,
    marginBottom: 20,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  button: {
    width: 60,
    height: 60,
    borderRadius: 10,
    backgroundColor: '#FB6F92',
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 24,
    color: '#fff',
  },
  inputContainer: {
    marginBottom: 20,
  },
  input: {
    height: 40,
    borderColor: '#FFB3C6',
    borderWidth: 6,
    padding: 10,
    fontSize: 24,
  },
  heading:{
    color:'#FFC2D1',
    fontweight:'bold',
    fontSize:28,
  }
});

export default Calculator;